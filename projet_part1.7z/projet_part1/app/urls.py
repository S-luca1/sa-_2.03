from django.urls import path
from . import peronnes_views, commentaires_views

urlpatterns = [

# pages pour les personnes
    path("index-personnes/", peronnes_views.index),
    path("traitement-personnes/", peronnes_views.traitement),
    path("ajout-personnes/", peronnes_views.ajout),
    path("affiche-personnes/<int:id>/", peronnes_views.affiche),
    path("update-personnes/<int:id>/", peronnes_views.update),
    path("updatetraitement-personnes/<int:id>/", peronnes_views.updatetraitement),
    path("delete-personnes/<int:id>/", peronnes_views.delete),

#page pour les commentaires
    path("index-commentaires/", commentaires_views.index),
    path("traitement-commentaires/", commentaires_views.traitement),
    path("ajout-commentaires/", commentaires_views.ajout),
    path("affiche-commentaires/<int:id>/", commentaires_views.affiche),
    path("update-commentaires/<int:id>/", commentaires_views.update),
    path("updatetraitement-commentaires/<int:id>/", commentaires_views.updatetraitement),
    path("delete-commentaires/<int:id>/", commentaires_views.delete),
    #path('commentaires/film/<int:film_id>/', commentaires_views.commentaires_par_film, name='commentaires-par-film'),
    ]
