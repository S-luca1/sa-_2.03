from django import forms
from django.forms import ModelForm
from . import models
from django.utils.translation import gettext_lazy as _

class PersonnesForm(ModelForm):
    motdepasse = forms.CharField(widget=forms.PasswordInput)

    class Meta :
        model = models.Personnes
        fields = '__all__'
        labels = {
            'nom' : _('Nom'),
            'prenom' : _('Prenom'),
            'pseudo' : _('Pseudo'),
            'mail' : _('Mail'),
            'motdepasse' : _('Motdepasse'),
            'type' : _('Type'),
        }

        widgets = {
            'id': forms.HiddenInput(),
        }

class CommentaireForm(ModelForm):
    class Meta:
        model = models.Commentaire
        fields = '__all__'
        labels = {
            #'film': _('Film'),
            'personne': _('Personne'),
            'note': _('Note'),
            'commentaire': _('Commentaire'),
            'date': _('Date'),
        }

        widgets = {
            'id': forms.HiddenInput(),
        }

