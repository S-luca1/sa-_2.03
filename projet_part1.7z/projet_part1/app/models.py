from django.db import models

class Personnes(models.Model):
    AMATEUR = 'AMATEUR'
    PROFESSIONNEL = 'PROFESSIONNEL'

    CHOIX_TYPE = [
        (AMATEUR, 'Amateur'),
        (PROFESSIONNEL, 'Professionnel'),
    ]

    pseudo = models.CharField(max_length=75, blank=False)
    nom = models.CharField(max_length=75, blank=False)
    prenom = models.CharField(max_length=75, blank=False)
    mail = models.EmailField(max_length=75, blank=False)
    motdepasse = models.CharField(max_length=75, blank=False)
    type = models.CharField(
        max_length=13,
        choices=CHOIX_TYPE,
        default=AMATEUR,
    )

    def __str__(self):
        chaine = f"{self.pseudo}"
        return chaine

    def dico(self):
        return {"pseudo": self.pseudo,
                "nom": self.nom,
                "prenom": self.nom,
                "mail": self.mail,
                "motdepasse": self.motdepasse,
                "type": self.type
                }
class Commentaire(models.Model):
    #film = models.ForeignKey("film", on_delete=models.CASCADE, default=None, blank=False)
    personne = models.ForeignKey("personnes", on_delete=models.CASCADE, default=None, blank=False)
    note = models.IntegerField(blank=False)
    commentaire = models.TextField(null=True, blank=False)
    date = models.DateField(blank=False)

    def __str__(self):
        chaine = f"Note : {self.note}, De : {self.personne}"
        return chaine

    def dico(self):
        return {#"film": self.film,
                "personne": self.personne,
                "note": self.note,
                "commentaire": self.commentaire,
                "date": self.date
                }

