from django.shortcuts import render, HttpResponseRedirect
from .forms import CommentaireForm
from . import models
from .models import Commentaire

def index(request):
    liste = list(models.Commentaire.objects.all())
    return render(request, "commentaires/index.html", {"liste": liste})


def ajout(request):
    if request.method == "POST":
        form = CommentaireForm(request)
        return render(request, "commentaires/ajout.html", {"form" : form})
    else :
        form = CommentaireForm
        return render(request, "commentaires/ajout.html", {"form" : form})


def traitement(request):
    cform = CommentaireForm(request.POST)
    if cform.is_valid():
        commentaire = cform.save()
        return HttpResponseRedirect("/index-commentaires/")
    else:
        return render(request, "commentaires/ajout.html", {"form": cform})


def affiche(request, id):
    commentaire = models.Commentaire.objects.get(pk=id)
    return render(request, "commentaires/affiche.html", {"commentaire": commentaire})


def update(request, id):
    commentaire = models.Commentaire.objects.get(pk=id)
    if request.method == "POST":
        form = CommentaireForm(request.POST, instance=commentaire)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/index-commentaires/")
    else:
        form = CommentaireForm(instance=commentaire)
    return render(request, "commentaires/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    commentaire = models.Commentaire.objects.get(pk=id)
    if request.method == "POST":
        form = CommentaireForm(request.POST, instance=commentaire)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/index-commentaires/")
    else:
        form = CommentaireForm(instance=commentaire)
    return render(request, "commentaires/ajout.html", {"form": form, "id": id})


def delete(request, id):
    commentaire = models.Commentaire.objects.get(pk=id)
    commentaire.delete()
    return HttpResponseRedirect("/index-commentaires/")
