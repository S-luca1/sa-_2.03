from django.shortcuts import render, HttpResponseRedirect
from .forms import PersonnesForm
from . import models


def index(request):
    liste = list(models.Personnes.objects.all())
    return render(request, "personnes/index.html", {"liste": liste})


def ajout(request):
    if request.method == "POST":
        form = PersonnesForm(request)
        return render(request, "personnes/ajout.html", {"form" : form})
    else :
        form = PersonnesForm
        return render(request, "personnes/ajout.html", {"form" : form})


def traitement(request):
    uform = PersonnesForm(request.POST)
    if uform.is_valid():
        personne = uform.save()
        return HttpResponseRedirect("/index-personnes/")
    else:
        return render(request, "personnes/ajout.html", {"form": uform})


def affiche(request, id):
    personne = models.Personnes.objects.get(pk=id)
    return render(request, "personnes/affiche.html", {"personne": personne})


def update(request, id):
    personne = models.Personnes.objects.get(pk=id)
    if request.method == "POST":
        form = PersonnesForm(request.POST, instance=personne)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/index-personnes/")
    else:
        form = PersonnesForm(instance=personne)
    return render(request, "personnes/ajout.html", {"form": form, "id": id})


def updatetraitement(request, id):
    personne = models.Personnes.objects.get(pk=id)
    if request.method == "POST":
        form = PersonnesForm(request.POST, instance=personne)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect("/index-personne/")
    else:
        form = PersonnesForm(instance=personne)
    return render(request, "personne/ajout.html", {"form": form, "id": id})


def delete(request, id):
    personne = models.Personnes.objects.get(pk=id)
    personne.delete()
    return HttpResponseRedirect("/index-personne/")